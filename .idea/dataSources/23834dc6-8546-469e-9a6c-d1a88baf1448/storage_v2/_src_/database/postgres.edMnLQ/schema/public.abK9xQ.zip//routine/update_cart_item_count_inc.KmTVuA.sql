create function update_cart_item_count_inc() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE carts SET item_count = item_count + 1 WHERE carts.user_id = NEW.cart_id;
    RETURN NEW;
END; $$;

alter function update_cart_item_count_inc() owner to s311293;

