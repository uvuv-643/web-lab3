create function getshopitems(shopid integer) returns items
    language sql
as
$$SELECT items FROM items JOIN shop_items ON items.id = shop_items.item_id WHERE shop_items.shop_id = shopId;$$;

alter function getshopitems(integer) owner to s311293;

